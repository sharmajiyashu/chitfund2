<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	 public function index() {
	   if(isset($_POST['submit'])&& $_POST['submit'] == 'submit'){
            $res = callApi('POST','SignIn',$_POST);
            $res_data = json_decode($res,true);
            if($res_data['status'] == 'success'){
                $this->session->set_userdata($res_data['data']);
                $this->session->set_flashdata('success', 'SignIn in Successfully');
                redirect('Dashboard');
            }else{
                $this->session->set_flashdata('Failed', 'Login Failed');
                redirect("Login");
            }
        }else{
            $this->load->view('login');
        }
    }
   

    public function Logout() {
        $this->session->sess_destroy();
        redirect('Login');
    }
}
