<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_id'))
            redirect('Login');
        date_default_timezone_set('Asia/Calcutta'); 
    }

    public function index() {
        $this->load->view('dashboard');
    }
    
    public function addSubscription(){
        $plan_id =  isset($_POST['plan_id']) ?  $_POST['plan_id'] : '';
        if (isset($_POST['submit']) && $_POST['submit'] == 'submit'){
            $data = array(
             'plan_name' =>   isset($_POST['plan_name']) ?  $_POST['plan_name'] : '',
             'admission_fee' =>   isset($_POST['admission_fee']) ?  $_POST['admission_fee'] : '',
             'plan_amount' =>   isset($_POST['plan_amount']) ?  $_POST['plan_amount'] : '',
             'tenure' =>   isset($_POST['tenure']) ?  $_POST['tenure'] : '',
             'start_month' =>   isset($_POST['start_month']) ?  $_POST['start_month'] : '',
             'agent_commission' =>   isset($_POST['agent_commission']) ?  $_POST['agent_commission'] : '',
             'emi' =>   isset($_POST['emi']) ?  $_POST['emi'] : '',
             'foreman_fees' =>   isset($_POST['foreman_fees']) ?  $_POST['foreman_fees'] : '',
             'min_prize_amount' =>   isset($_POST['min_prize_amount']) ?  $_POST['min_prize_amount'] : '',
             'total_subscription' =>   isset($_POST['total_subscription']) ?  $_POST['total_subscription'] : '',  
             'months_completed' =>   isset($_POST['months_completed']) ?  $_POST['months_completed'] : '',  
             'total_months' =>   isset($_POST['total_months']) ?  $_POST['total_months'] : '',  
             'groups_counts' =>   isset($_POST['groups_counts']) ?  $_POST['groups_counts'] : '',  
             'end_date_for_subscription' =>   isset($_POST['end_date_for_subscription']) ?  $_POST['end_date_for_subscription'] : '',  
             'max_bid' =>   isset($_POST['max_bid']) ?  $_POST['max_bid'] : '',      
            );
           if(empty($plan_id)){
                $res = Json_decode(callAPI('POST','addPlan',$data));
                if($res->status == 'success'){
                    redirect('Dashboard/subscription_listing');
                }else{
                   redirect('Dashboard/subscription_listing'); 
                }
           }else{
               $data = array(
                 'plan_id'  => isset($_POST['plan_id']) ?  $_POST['plan_id'] : '',
                 'plan_name' =>   isset($_POST['plan_name']) ?  $_POST['plan_name'] : '',
                 'admission_fee' =>   isset($_POST['admission_fee']) ?  $_POST['admission_fee'] : '',
                 'plan_amount' =>   isset($_POST['plan_amount']) ?  $_POST['plan_amount'] : '',
                 'tenure' =>   isset($_POST['tenure']) ?  $_POST['tenure'] : '',
                 'start_month' =>   isset($_POST['start_month']) ?  $_POST['start_month'] : '',
                 'agent_commission' =>   isset($_POST['agent_commission']) ?  $_POST['agent_commission'] : '',
                 'emi' =>   isset($_POST['emi']) ?  $_POST['emi'] : '',
                 'total_subscription' =>   isset($_POST['total_subscription']) ?  $_POST['total_subscription'] : '',  
                 'months_completed' =>   isset($_POST['months_completed']) ?  $_POST['months_completed'] : '',  
                 'total_months' =>   isset($_POST['total_months']) ?  $_POST['total_months'] : '',  
                 'groups_counts' =>   isset($_POST['groups_counts']) ?  $_POST['groups_counts'] : '',  
                 'end_date_for_subscription' =>   isset($_POST['end_date_for_subscription']) ?  $_POST['end_date_for_subscription'] : '',             
                );
                $res = Json_decode(callAPI('POST','planUpdateDetails',$data));
                if($res->status == 'success'){
                    redirect('Dashboard/subscription_listing');
                }else{
                   redirect('Dashboard/subscription_listing'); 
                }  
            }
        }else{
            $this->load->view('add-plan');
        }
    }
    
    public function subscription_listing(){
        $res = json_decode(callAPI('GET','getPlans'));
	    if($res->status == 'success'){
	               $this->load->view('plan-listing', array('getPlans' => $res->data));
	    }else{
	        redirect('Dashboard/addSubscription');
	    }
    }

    public function subscriptionDelete($id = '') {
        $this->db->Where('plan_id',$id)->delete('tbl_plans');
        redirect('Dashboard/subscription_listing');
    }

   
   
   public function addAgent(){ 
        $agent_id = $this->input->post('agent_id');
        if (isset($_POST['submit']) && $_POST['submit'] == 'submit'){
            $first_name = $this->input->post('fname');
            $last_name = $this->input->post('lname');
            $email = $this->input->post('email');
            $phone = $this->input->post('phone');
            $gst_no = $this->input->post('gst_no');
            $company = $this->input->post('company');
            $payment_terms = $this->input->post('payment_terms');
            $address = $this->input->post('address');
            $city = $this->input->post('city');
            $state = $this->input->post('state');
            $country = $this->input->post('country');
            $data = array(
                'first_name' => isset($first_name) ? $first_name : '',
                'last_name' => isset($last_name) ? $last_name : '',
                'email' => isset($email) ? $email : '',
                'phone' => isset($phone) ? $phone : '',
                'gst_no' => isset($gst_no) ? $gst_no : '',
                'company' => isset($company) ? $company : '',
                'payment_terms' => isset($payment_terms) ? $payment_terms : '',
                'address' => isset($address) ? $address : '',
                'city' => isset($city) ? $city : '',
                'state' => isset($state) ? $state : '',
                'country' => isset($country) ? $country : '',
            );
         if(empty($agent_id)){
            $res = json_decode(callAPI('POST','addAgent',$data));
    	    if($res->status == 'Success'){
    	        redirect('Dashboard/agent_listing');
    	    }else{
    		    redirect('Dashboard/agent_listing');
    		}
         }else{
            $res = json_decode(callAPI('POST','agentUpdateDetails',$_POST));
    	    if($res->status == 'Success'){
    	        redirect('Dashboard/agent_listing');
    	    }else{
    		    redirect('Dashboard/agent_listing');
    		} 
         }
        }else{
            $this->load->view('add-agent');
        }
    }
    
    public function agent_listing() {
        $res = json_decode(callAPI('GET','getAllAgentDetails'));
	    if($res->status == 'success'){
	        $this->load->view('agent-listing', array('get_supplier' => $res->data));
	    }else{
	        redirect('Dashboard/addAgent');
	    }
    }
    

    public function agent_delete($id = '') {
        $this->db->where('agent_id', $id)->delete('tbl_agent');
        redirect('Dashboard/agent_listing');
    }

    public function change_status_agent($id = '') {
        $this->load->model('Supplier_Model');
        $this->Supplier_Model->change_status_supplier($id);
        redirect('Dashboard/supplier_listing');
    }
    
    
    public function addSubscriber(){ 
        $member_id = isset($_POST['member_id']) ?  $_POST['member_id'] : '';
        if (isset($_POST['submit']) && $_POST['submit'] == 'submit'){
            $data = array(
             'name' =>   isset($_POST['name']) ?  $_POST['name'] : '',
             'last_name' =>   isset($_POST['last_name']) ?  $_POST['last_name'] : '',
             'father_name' =>   isset($_POST['father_name']) ?  $_POST['father_name'] : '',
             'dob' =>   isset($_POST['dob']) ?  $_POST['dob'] : '',
             'mobile' =>   isset($_POST['mobile']) ?  $_POST['mobile'] : '',
             'secondary_mobile' =>   isset($_POST['secondary_mobile']) ?  $_POST['secondary_mobile'] : '',
             'office_phone' =>   isset($_POST['office_phone']) ?  $_POST['office_phone'] : '',
             'email' =>   isset($_POST['email']) ?  $_POST['email'] : '',
             'permanent_address' =>   isset($_POST['address']) ?  $_POST['address'] : '',
             'current_potal_address' =>   isset($_POST['potal_address']) ?  $_POST['potal_address'] : '',
             'reference' =>   isset($_POST['reference']) ?  $_POST['reference'] : '',
             'marital_status' =>   isset($_POST['marital_status']) ?  $_POST['marital_status'] : '',
             'spouse_name' =>   isset($_POST['spouse_name']) ?  $_POST['spouse_name'] : '',
             'annivarsary_date' =>   isset($_POST['annivarsary_date']) ?  $_POST['annivarsary_date'] : '',
             'no_of_kids' =>   isset($_POST['kids']) ?  $_POST['kids'] : '',
             'no_of_depend' =>   isset($_POST['dependents']) ?  $_POST['dependents'] : '',
             'nominee_name' =>   isset($_POST['nominee_name']) ?  $_POST['nominee_name'] : '',
             'nominee_relationship' =>   isset($_POST['nominee_relationship']) ?  $_POST['nominee_relationship'] : '',
             'nominee_d_o_b' =>   isset($_POST['nominee_dob']) ?  $_POST['nominee_dob'] : '',
             'percentage_of_nomination' =>   isset($_POST['nominee_percentage']) ?  $_POST['nominee_percentage'] : '',
             'nominee_gaurdian_name' =>   isset($_POST['guardian_name']) ?  $_POST['guardian_name'] : '',
             'pan_number' =>   isset($_POST['Pan']) ?  $_POST['Pan'] : '',
             'adhaar_number' =>   isset($_POST['Aadhar']) ?  $_POST['Aadhar'] : '',
             'income_type' =>   isset($_POST['income_type']) ?  $_POST['income_type'] : '',
             'company_name' =>   isset($_POST['company_name']) ?  $_POST['company_name'] : '',
             'company_type' =>   isset($_POST['company_type']) ?  $_POST['company_type'] : '',
             'designation' =>   isset($_POST['designation']) ?  $_POST['designation'] : '',
             'work_address' =>   isset($_POST['work_address']) ?  $_POST['work_address'] : '',
             'salary' =>   isset($_POST['salary']) ?  $_POST['salary'] : '',
             'other_income' =>   isset($_POST['other_income']) ?  $_POST['other_income'] : '',
             'experience' =>   isset($_POST['experience']) ?  $_POST['experience'] : '',
             'professional_service' =>   isset($_POST['professional_service']) ?  $_POST['professional_service'] : '',
             'office_address' =>   isset($_POST['office_address']) ?  $_POST['office_address'] : '',
             'employee_no' =>   isset($_POST['employee_no']) ?  $_POST['employee_no'] : '',
             'gst_no' =>   isset($_POST['gst']) ?  $_POST['gst'] : '',
             'annual_turnover' =>   isset($_POST['annual_turnover']) ?  $_POST['annual_turnover'] : '',
             'income_source' =>   isset($_POST['income_source']) ?  $_POST['income_source'] : '',
             'monthly_income' =>   isset($_POST['monthly_income']) ?  $_POST['monthly_income'] : '',
             'car_category' =>   isset($_POST['car_category']) ?  $_POST['car_category'] : '',
             'two_wheeler_category' =>   isset($_POST['two_wheeler_category']) ?  $_POST['two_wheeler_category'] : '',
             'house_category' =>   isset($_POST['house_category']) ?  $_POST['house_category'] : '',
             'identity_category' =>   isset($_POST['identity_category']) ?  $_POST['identity_category'] : '',
             'address_category' =>   isset($_POST['address_category']) ?  $_POST['address_category'] : '', 
             'agent_id' => 1,
             'agent_comission' => 5,
             'no_of_nominee' => 3
            );
            
            if(empty($member_id)){
                $res = json_decode(callAPI('POST','addMember',$data));
                if($res->status == 'success'){
        	        redirect('Dashboard/subscriber_listing');
        	    }else{
        		    redirect('Dashboard/subscriber_listing');
        		}
            }else{
                $res = json_decode(callAPI('POST','subscriberUpdateDetails',$_POST));
                if($res->status == 'success'){
        	        redirect('Dashboard/subscriber_listing');
        	    }else{
        		    redirect('Dashboard/subscriber_listing');
        		}
            }
        }else{
            $this->load->view('add-member');
        }
    }
    
    public function subscriber_listing() {
        $res = json_decode(callAPI('GET','getAllMemberDetails'));
	    if($res->status == 'success'){
	        $this->load->view('member-listing', array('get_member' => $res->data));
	    }else{
	        redirect('Dashboard/addSubscriber');
	    }
    }
    
    public function member_delete($id = '') {
        $this->db->where('member_id',$id)->delete('tbl_members');
        redirect('Dashboard/subscriber_listing');
    }

    public function subscriptionUpdate($plan_id=''){
        $data = array(
          'plan_id' =>   isset($plan_id) ?  $plan_id : ''
        );
        $res = callAPI('POST','planUpdate',$data);
        $put= json_decode($res,true);
        $data = $put['data'];
        if($put['status'] == 'success'){
         $this->load->view('add-plan',array('data' => $data));   
        }else{
          redirect('Dashboard/subscription_listing');  
        }
    }

    public function agentUpdate($agent_id=''){
        $data = array(
           'agent_id' =>   isset($agent_id) ?  $agent_id : ''
        );       
        
        $res=callAPI('POST','agentUpdate',$data);
        $put= json_decode($res,true);
        $data = isset($put['data']) ? $put['data'] : '';
        if($put['status'] == 'success'){
           $this->load->view('add-agent',array('data' => $data)); 
        }else{
          redirect('Dashboard/agent_listing');
        }
    }

    public function subscriberupdate($member_id=''){
        $data = array(
           'member_id' => isset($member_id) ?  $member_id : ''
        );
        $res=callAPI('POST','subscriberupdate',$data);        
        $put= json_decode($res,true);
        $data = isset($put['data']) ? $put['data'] : '' ;
        if($put['status'] == 'success'){
          $this->load->view('add-member',array('data' => $data));    
        }else{
          redirect('Dashboard/subscriber_listing');
        }
    }

    public function agentDelete($agent_id=''){
        $data = array(
            'agent_id' =>   isset($agent_id) ?  $agent_id : ''
        );
        $res=callAPI('POST','agentDelete',$data);
        redirect('Dashboard/agent_listing');
    }
    
    public function GetGroupinplan($plan_id=''){
        $data = array(
            'plan_id' =>   isset($plan_id) ?  $plan_id : ''
        );
        $res=callAPI('POST','getGroupInAPlan',$data);        
        $data = json_decode($res,true);
        $data =  isset($data['data']) ? $data['data'] : '';
        $this->load->view('group-listing',array('data'=> $data));
    }

    public function getgroupdetail($group_id=''){
        $data = array(
            'group_id' =>   isset($group_id) ?  $group_id : ''
        );
        $res=json_decode(callAPI('POST','getGroupDetails',$data),true);  
        $res1 = isset($res['data'])? $res['data'] : '';
        $subscriber_listing = json_decode(callAPI('GET','getAllMemberDetails'),true);
        $subscriber_listing1 = isset($subscriber_listing['data']) ? $subscriber_listing['data'] : '';
        $this->load->view('plan_group_member',array('data'=> $res1,'subscriber_listing' => $subscriber_listing1,'group_id' => $group_id));
    }
    public function getmoreviewmember($member_id=''){
        $data = array(
            'member_id' =>   isset($member_id) ?  $member_id : ''
        );
        $res=json_decode(callAPI('POST','getMembersDetails',$data),true);  
        $this->load->view('member_profile',array('data'=>$res['data']));
    }

    public function getplan_history($member_id=''){
        $data = array(
            'member_id' =>   isset($member_id) ?  $member_id : '',
            'status'=> '0'
        );        
        $res=json_decode(callAPI('POST','plansPurchasedByMember',$data),true);  
        if($res['status'] == 'success'){
            $this->load->view('member_active_plan',array('data'=>$res['data']));
        }
        else{
            redirect('Dashboard/getmoreviewmember/'.$member_id);
        }        
    }

    public function buy_active_plan($member_id=''){             
        $res=json_decode(callAPI('POST','getPlans'),true);  
        if($res['status'] == 'success'){
            $this->load->view('buy-plan-member',array('data'=>$res['data'],'member_id'=>$member_id));
        }
        else{
            redirect('Dashboard/getmoreviewmember/'.$member_id);
        }        
    }

    public function buy_plan_by_agent($plan_id='',$member_id=''){     
        $data = array(
            'member_id' =>   isset($member_id) ?  $member_id : '',
            'plan_id' =>   isset($plan_id) ?  $plan_id : '',
        ); 
        $res=callAPI('POST','BuyPlanByAgent',$data);  
        $data = json_decode($res,true);   
        if($data['status'] == 'Success'){
            $this->load->view('buy-plan-member',array('data'=>$data['data'],'member_id'=>$member_id));
        }
        else{
            redirect('Dashboard/buy_active_plan/'.$member_id);
        }        
    }

    public function plan_emi_due($member_id=''){     
        $data = array(
            'member_id' =>   isset($member_id) ?  $member_id : '',           
        ); 
        $res=callAPI('POST','getEmiInPlan',$data);  
        $data = json_decode($res,true);  
        if($data['status'] == 'success'){
            $this->load->view('plan_emi_due',array('data'=>$data['data']));
        }
        else{
            redirect('Dashboard/buy_active_plan/'.$member_id);
        }        
    }
    
    public function cancelSubscription(){
        $data = array(
            'slot_number' => isset($_POST['slot_number']) ? $_POST['slot_number'] : '',
            'order_id' => isset($_POST['order_id']) ? $_POST['order_id'] : ''
        );
        $res=json_decode(callAPI('POST','cancelSubscription',$data),true); 
        if($res['status'] == 'success'){
            $output = 'Cancelled Successfully';
        }else{
            $output = 'Something Wrong';
        }
        echo json_encode($output); die;
    }
    
    public function resignSlotSubcription(){
        $data = array(
          'slot_number' => isset($_POST['slot_number']) ? $_POST['slot_number'] : '',
          'member_id' => isset($_POST['member_id']) ? $_POST['member_id']  : '',
          'order_id' => isset($_POST['order_id']) ? $_POST['order_id']  : ''
        );
        $res=json_decode(callAPI('POST','resignSlotSubcription',$data),true); 
        if($res['status'] == 'success'){
            $output = 'Insert Subscription Successfully';
        }else{
            $output = 'Something Wrong';
        }
        echo json_encode($output); die;
    }
    
    public function addCollateral(){
      if(isset($_POST['submit'])){
        $res = json_decode(callAPI('POST','addCollateral',$_POST),true);  
        if($res['status'] == 'success'){
            redirect('Dashboard/listCollateral');
        }else{
           $this->load->view('add-collateral'); 
        }
      }else{
         $this->load->view('add-collateral');
      }
    }
    
    public function listCollateral(){
       $res = json_decode(callAPI('GET','listCollateral'),true);  
       if($res['status'] == 'success'){
        $this->load->view('collateral-listing',array('getCollateral' => $res['data']));
       }else{
         $this->load->view('collateral-listing');
       } 
    }
    
    public function subCollateralList(){
       $collateral_id = isset($_POST['collateral_id']) ? $_POST['collateral_id'] : '';
       $getCollateral =  $this->db->where('parent_id',$collateral_id)->get('tbl_collateral_master')->result_array();
       $output = '';
       $output .=' <select class="form-control" name="sub_collateral">
                        <option value="0">Select Type</option>';
       foreach($getCollateral as $key => $value){ 
        $output .='<option value="'.$value["collateral_id"].'">'.$value["name"].'</option>';
       }
       $output .='</select>';
       echo json_encode($output); die;
    }
    
    public function addSubscriberCollateral(){
       $res = json_decode(callAPI('POST','addSubscriberCollateral',$_POST),true); 
       if($res['status'] == 'success'){
          $output = array(
           'status' => 'Success',
           'message' => 'Add Subscriber Collateral Successfully',
           'data' => []
          );
       }else{
          $output = array(
           'status' => 'Failure',
           'message' => 'Add Subscriber Collateral Unsuccessfully',
           'data' => []
          );
       }  
       echo json_encode($output); die;
    }
    
    public function getControlSheet(){
       $res = json_decode(callAPI('GET','getControlSheet'),true);
       if($res['status'] == 'success'){
          $this->load->view('control-sheet-list',array('getControl' => $res['data']));
       }else{
         $this->load->view('control-sheet-list');
       }  
    }
    
    public function getSlotNumber(){
        $collateral_id = isset($_POST['collateral_id']) ? $_POST['collateral_id'] :  '';
       $member_id = isset($_POST['member_id']) ? $_POST['member_id'] : '';
       // $getMember_id = $this->db->select('member_id')->where('collateral_id',$collateral_id)->get('tbl_subscriber_collateral')->row_array();
        $getSlot = $this->db->where('slot_status','assigned')->where('member_id',$member_id)->get('tbl_orders')->result_array();
        $output = '';
        $output .='<div><label>Select Subscription</label><select id="slotnumber" class="form-control" name="slotnumber">
                        <option value="0">Select Type</option>';
       foreach($getSlot as $key => $value){ 
        $output .='<option value="'.$value["slot_number"].'">'.$value["slot_number"].'</option>';
       }
       $output .='</select></div>';
       echo json_encode($output); die;
    }
    
    public function reports($member_id = ''){
        $data = array(
            'member_id' => isset($member_id) ? $member_id : ''
        );
        $res = json_decode(callAPI('POST','reports',$data),true);
        if($res['status'] == 'success'){
            $this->load->view('reports',array('data'=>$res['data']));
        }else{
            $this->load->view('reports');
        }
    }
    
    public function planAvailableForAuction(){
        $res = json_decode(callAPI('get','getPlansAvailableForAuction'),true);  
        if($res['status'] == 'success'){
            $this->load->view('plan-available-for-auction',array('data'=>$res['data']));
        }
    }
    
    public function planGroupForAuction($plan_id = ''){
        $data = array(
           'plan_id' => isset($plan_id) ? $plan_id : '',
        );
        $res=json_decode(callAPI('POST','plangroupsforauction',$data),true);
        $result = array();
        foreach ($res['data'] as $key => $value) {
            $result[$key] =  $value;
            $result[$key]['plan_name'] = isset($_POST['plan_name']) ? $_POST['plan_name'] : '';
        }
        if($res['status'] == 'success'){ 
            $this->load->view('plan-group-for-auction',['data' => $result]);
        }else{
            redirect('Dashboard/planAvailableForAuction');
        }
    }
    
    public function liveAuction($auction_id = ''){
        $group_name = isset($_POST['group_name']) ? $_POST['group_name'] : '';
        $forman_fees = isset($_POST['forman_fees']) ? $_POST['forman_fees'] : '';
        $plan_name = isset($_POST['plan_name']) ? $_POST['plan_name'] : '';
        $group_id = isset($_POST['group_id']) ? $_POST['group_id'] : '';
        
         $dataBid = array(
            'auction_id' => isset($auction_id) ? $auction_id : '',
         );
         $getBidsForAuction= json_decode(callAPI('POST','getbidsforauction',$dataBid),true);
         
         $dataMemberAuction = array(
           'auction_id' => isset($auction_id) ? $auction_id : '',
           'type' => isset($type) ? $type : 'individual',
         );
        
        $getMembersInAuction= json_decode(callAPI('POST','getMembersInAuction',$dataMemberAuction),true);
    
        $dataliveAuction = array(
            
         'getBidsForAuction' => $getBidsForAuction['data'],
         'getMembersInAuction' => $getMembersInAuction['data'],
         'group_name' => $group_name,
         'plan_name' => $plan_name,
         'forman_fees' => $forman_fees,
         'auction_id' => $auction_id,
         'group_id' => $group_id
         
        );
        
        if($getMembersInAuction['status'] == 'success'){
            $this->load->view('live-auction',$dataliveAuction);
        }else{
          $this->load->view('live-auction');  
        }
    }
    
    public function SwitchCombinedAuction(){
        $dataMemberAuction = array(
           'auction_id' => isset($_POST['auction_id']) ? $_POST['auction_id'] : '',
           'type' => isset($_POST['type']) ? $_POST['type'] : ''
        );
       $getMembersInAuction= json_decode(callAPI('POST','getMembersInAuction',$dataMemberAuction),true);
       $output = '';
       $output .='<div class="container" id="test">
                    <h5>List of open Sub ld For Auction</h5>';
                    if (isset($getMembersInAuction['data']) && is_array($getMembersInAuction['data'])) { 
                    foreach($getMembersInAuction['data'] as $key => $values) { 
                        
    			 $output .='<div class="list-group">
    				     <input type="hidden" name="auction_id" value="'.$_POST["auction_id"].'" id="auction_id">
    				     <input type="hidden" name="agent_id" value="'.$values["agent_id"].'" id="agent_id">
    				     <input type="hidden" name="group_id" value="'.$_POST["group_id"].'" id="group_id">
    				  	<div class="row" style="margin-top: 15px;"> 
    					    <button class="col-md-3" style="border-radius: 12px; background: #FF4000;color: white; margin-left: 10px;">sub.id-'.$values["member_id"].'</button>
    					    <input class="col-md-3" id="forGoAmount_'.$values["member_id"].'"  name="for_go_amount" type="text" placeholder="Bid Amt" style="border-radius: 12px; margin-left: 10px;background: #A4A4A4;color: white;">
    					    <button class="col-md-3 " type="submit" name="submit" style="border-radius: 12px; background: #0B0719; margin-left: 10px;color: white;" onclick="openModal('.$values["member_id"].')" >Submit</button>
    				    </div>
    				  </div>';
                   }
                   }
			$output .'</div>';
       echo json_encode($output); die;
    }
    
    public function endAuction($auction_id = ''){
        $data = array(
            'auction_id' => isset($auction_id) ? $auction_id : '',
        );
        $saveBidByAgent= json_decode(callAPI('POST','endauctionnow',$data),true);      
        if($saveBidByAgent['status'] == 'success'){
            $this->session->set_flashdata('success', 'Auction close');
            redirect("Dashboard/planAvailableForAuction");
        }
        else{
            $this->session->set_flashdata('Failure','Auction is already close');
            redirect("Dashboard/planAvailableForAuction");
        }
    }
    
    public function cancleAuction($auction_id = ''){
        $data = array(
            'auction_id' => isset($auction_id) ? $auction_id : '',
        );
        $cancelAuction= json_decode(callAPI('POST','cancelAuction',$data),true);     
        print_r($cancelAuction);die; 
        if($cancelAuction['status'] == 'success'){
            $this->session->set_flashdata('success', 'Cancle auction');
            redirect("Dashboard/planAvailableForAuction");
        }
        else{
            $this->session->set_flashdata('Failure','cancle auction already');
            redirect("Dashboard/planAvailableForAuction");
        }
    }
    
    public function saveBidByAgent(){
        $data = array(
            "member_id" => isset($_POST['member_id']) ? $_POST['member_id'] : '',
            "auction_id" => isset($_POST['auction_id']) ? $_POST['auction_id'] : '',
            "for_go_amount" => isset($_POST['for_go_amount']) ? $_POST['for_go_amount'] : '',
            "agent_id" => isset($_POST['agent_id']) ? $_POST['agent_id'] : '',
            "group_id" => isset($_POST['group_id']) ? $_POST['group_id'] : '',
         );
        $saveBidByAgent= json_decode(callAPI('POST','saveBidByAgent',$data),true);
        $output = '';
        if($saveBidByAgent['status'] == 'success'){
          $output .= $saveBidByAgent['message'];   
       }else{
          $output .= $saveBidByAgent['message'];    
       }
       echo json_encode($output);
    }
    
    public function savefinalbid(){
        $data = array(
            "bid_id" => isset($_POST['bid_id']) ? $_POST['bid_id'] : '',
        );
       $savefinalbid= json_decode(callAPI('POST','savefinalbid',$data),true); 
       $output = '';
        if($savefinalbid['status'] == 'success'){
          $output .= $savefinalbid['message'];   
       }else{
          $output .= $savefinalbid['message'];    
       }
       echo json_encode($output);
    }
    
    public function startAuction(){
      $startAuction= json_decode(callAPI('POST','startAuction',$_POST),true); 
      if($startAuction['status'] == 'success'){
          redirect('Dashboard/planAvailableForAuction');
      }else{
          redirect('Dashboard/planAvailableForAuction');  
      }
       
    }
    
    public function exportSubscription(){
         $file_name = 'Subscription'.date('Ymd').'.csv'; 
         header("Content-Description: File Transfer"); 
         header("Content-Disposition: attachment; filename=$file_name"); 
         header("Content-Type: application/csv;");
         // get data 
     
         // file creation 
        $file = fopen('php://output', 'w');
        $header =array();
        $header = array(
             "plan_name",
             "admission_fees",
             "plan_amount",
             "tenure",
             "start_month",
             "agent_commission",
             "emi",
             "total_months",
             "groups_counts",
             "end_date_for_subscription",
             "foreman_fees",
             "min_prize_amount",
             "max_bid"
        ); 
        fputcsv($file, $header);
        fclose($file); 
        exit; 
    }
   
    public function importSubscription(){
         // Check form submit or not 
        if(!empty($_FILES['file']['name'])){ 
         // Set preference 
        
         $config['upload_path'] = 'images/'; 
         $config['allowed_types'] = 'csv'; 
         $config['max_size'] = '10000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name'];

         // Load upload library 
         $this->load->library('upload',$config); 
 
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data(); 
            $filename = $uploadData['file_name'];

            // Reading file
            $file = fopen("images/".$filename,"r");
            $i = 0;
            $numberOfFields = 13; // Total number of fields
            $importData_arr = array();
 
            while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
               $num = count($filedata );
                
               if($numberOfFields == $num){
                  for ($c=0; $c < $num; $c++) {
                     $importData_arr[$i][] = $filedata [$c];
                  }
               }
               $i++;
            }
            fclose($file);

            $skip = 0;

            // insert import data
            foreach($importData_arr as $userdata){
                
               // Skip first row
               if($skip != 0){
                
                 $data = array(
                     "plan_name" => isset($userdata[0]) ? $userdata[0] : '',
                     "admission_fee" => isset($userdata[1]) ? $userdata[1]: '',
                     "plan_amount" => isset($userdata[2]) ? $userdata[2] : '',
                     "tenure" => isset($userdata[3]) ? $userdata[3] : '',
                     "start_month" => isset($userdata[4]) ? $userdata[4] : '',
                     "agent_commission" => isset($userdata[5]) ? $userdata[5] : '',
                     "emi" => isset($userdata[6]) ? $userdata[6] : '',
                     "total_months" => isset($userdata[7]) ? $userdata[7] : '',
                     "groups_counts" => isset($userdata[8]) ? $userdata[8] : '',
                     "end_date_for_subscription" => isset($userdata[9]) ? $userdata[9] : '',
                     "foreman_fees" => isset($userdata[10]) ? $userdata[10] : '',
                     "min_prize_amount" => isset($userdata[11]) ? $userdata[11] : '',
                     "max_bid" => isset($userdata[12]) ? $userdata[12] : '',
                    );  
                    $res = Json_decode(callAPI('POST','addPlan',$data));
               }
               $skip ++;
            }
            $data['response'] = 'successfully uploaded '.$filename; 
         }else{ 
            $data['response'] = 'failed'; 
         } 
      }else{ 
         $data['response'] = 'failed'; 
      } 
      // load view 
      redirect('Dashboard/subscription_listing');
  }
  
  public function exportSubscriber(){
      $file_name = 'Subscriber'.date('Ymd').'.csv'; 
         header("Content-Description: File Transfer"); 
         header("Content-Disposition: attachment; filename=$file_name"); 
         header("Content-Type: application/csv;");
         // get data 
     
         // file creation 
        $file = fopen('php://output', 'w');
        $header =array();
        $header = array(
            "name",
            "last_name",
            "father_name",
            "dob	",
            "mobile",
            "secondary_mobile",
            "office_phone	",
            "email",
            "permanent_address",
            "current_potal_address",
            "marital_status",
            "spouse_name",
            "annivarsary_date",
    		"no_of_kids",
    		"no_of_depends",
    		"no_of_nominee",
    		"nominee_name",
    		"nominee_relationship",
    		"nominee_d_o_b",
    		"percentage_of_nomination",
    		"nominee_gaurdian_name",
            "pan_number",
            "income_type",
            "company_name",
            "company_type",
            "designation",
            "work_address",
            "salary",
            "other_income",
            "experience",
            "for_self_employed",
            "for_professional_service",
            "office_address",
            "employee_no",
            "gst_no",
            "annual_turnover",
            "income_source",
            "monthly_income",
            "car_category",
            "two_wheeler_category",
            "house_category",
            "identity_category",
            "address_category",
            "is_added_by_agent",
            "agent_id",
            "agent_comission",
            "adhaar_number",
        ); 
        fputcsv($file, $header);
        fclose($file); 
        exit;
  }
  
  public function importSubscriber(){
     // Check form submit or not 
        if(!empty($_FILES['file']['name'])){ 
         // Set preference 
        
         $config['upload_path'] = 'images/'; 
         $config['allowed_types'] = 'csv'; 
         $config['max_size'] = '10000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name'];

         // Load upload library 
         $this->load->library('upload',$config); 
 
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data(); 
            $filename = $uploadData['file_name'];

            // Reading file
            $file = fopen("images/".$filename,"r");
            $i = 0;
            $numberOfFields = 13; // Total number of fields
            $importData_arr = array();
 
            while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
               $num = count($filedata );
                
               if($numberOfFields == $num){
                  for ($c=0; $c < $num; $c++) {
                     $importData_arr[$i][] = $filedata [$c];
                  }
               }
               $i++;
            }
            fclose($file);

            $skip = 0;

            // insert import data
            foreach($importData_arr as $userdata){
                
               // Skip first row
               if($skip != 0){
                
                 $header = array(
                        "name" => isset($value[0]) ? $value[0] : '',
                        "last_name"  => isset($value[1]) ? $value[1] : '',
                        "father_name" => isset($value[2]) ? $value[2] : '',
                        "dob" => isset($value[3]) ? $value[3] : '',
                        "mobile"  => isset($value[4]) ? $value[4] : '',
                        "secondary_mobile" => isset($value[5]) ? $value[5] : '',
                        "office_phone" => isset($value[6]) ? $value[6] : '',
                        "email" => isset($value[7]) ? $value[7] : '',
                        "permanent_address" =>  isset($value[8]) ? $value[8] : '',
                        "current_potal_address" => isset($value[9]) ? $value[9] : '',
                        "marital_status" =>  isset($value[10]) ? $value[10] : '',
                        "spouse_name" => isset($value[11]) ? $value[11] : '',
                        "annivarsary_date" => isset($value[12]) ? $value[12] : '',
                		"no_of_kids" => isset($value[13]) ? $value[13] : '',
                		"no_of_depends" => isset($value[14]) ? $value[14] : '',
                		"no_of_nominee" => isset($value[15]) ? $value[15] : '',
                		"nominee_name"  => isset($value[16]) ? $value[16] : '',
                		"nominee_relationship" => isset($value[17]) ? $value[17] : '',
                		"nominee_d_o_b" => isset($value[18]) ? $value[18] : '',
                		"percentage_of_nomination" => isset($value[19]) ? $value[19] : '',
                		"nominee_gaurdian_name"  => isset($value[20]) ? $value[20] : '',
                        "pan_number" => isset($value[21]) ? $value[21] : '',
                        "income_type" => isset($value[22]) ? $value[22] : '',
                        "company_name" => isset($value[23]) ? $value[23] : '',
                        "company_type" => isset($value[24]) ? $value[24] : '',
                        "designation" => isset($value[25]) ? $value[25] : '',
                        "work_address" => isset($value[26]) ? $value[26] : '',
                        "salary" => isset($value[27]) ? $value[27] : '',
                        "other_income" => isset($value[28]) ? $value[28] : '',
                        "experience" => isset($value[29]) ? $value[29] : '',
                        "for_self_employed" => isset($value[30]) ? $value[30] : '',
                        "for_professional_service" => isset($value[31]) ? $value[31] : '',
                        "office_address" => isset($value[32]) ? $value[32] : '',
                        "employee_no" => isset($value[33]) ? $value[33] : '',
                        "gst_no" => isset($value[34]) ? $value[34] : '',
                        "annual_turnover" => isset($value[35]) ? $value[35] : '',
                        "income_source" => isset($value[36]) ? $value[36] : '',
                        "monthly_income" => isset($value[37]) ? $value[37] : '',
                        "car_category" => isset($value[38]) ? $value[38] : '',
                        "two_wheeler_category" => isset($value[39]) ? $value[39] : '',
                        "house_category" => isset($value[40]) ? $value[40] : '',
                        "identity_category" => isset($value[41]) ? $value[41] : '',
                        "address_category" => isset($value[42]) ? $value[42] : '',
                        "is_added_by_agent" => isset($value[43]) ? $value[43] : '',
                        "agent_id" => isset($value[44]) ? $value[44] : '',
                        "agent_comission" => isset($value[45]) ? $value[45] : '',
                        "adhaar_number" => isset($value[46]) ? $value[46] : '',
                    ); 
                    $res = Json_decode(callAPI('POST','addMember',$data));
               }
               $skip ++;
            }
            $data['response'] = 'successfully uploaded '.$filename; 
         }else{ 
            $data['response'] = 'failed'; 
         } 
      }else{ 
         $data['response'] = 'failed'; 
      } 
      // load view 
      redirect('Dashboard/subscriber_listing');
  }
  
}
