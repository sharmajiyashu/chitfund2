<!-- Backend Bundle JavaScript -->
<script src="<?php echo base_url(); ?>assets/assets/js/backend-bundle.min.js"></script>

<!-- Table Treeview JavaScript -->
<script src="<?php echo base_url(); ?>assets/assets/js/table-treeview.js"></script>

<!-- Chart Custom JavaScript -->
<script src="<?php echo base_url(); ?>assets/assets/js/customizer.js"></script>

<!-- Chart Custom JavaScript -->
<script async src="<?php echo base_url(); ?>assets/assets/js/chart-custom.js"></script>

<!-- app JavaScript -->
<script src="<?php echo base_url(); ?>assets/assets/js/app.js"></script>