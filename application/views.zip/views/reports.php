<!doctype html>
<html lang="en">
    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
    <style>
        @import url(http://fonts.googleapis.com/css?family=Calibri:400,300,700);


.mt-100 {
    margin-top: 50px
}

.mb-100 {
    margin-bottom: 50px
}

.card {
    border-radius: 1px !important
}

.card-header {
    background-color: #fff
}

.card-header:first-child {
    border-radius: calc(0.25rem - 1px) calc(0.25rem - 1px) 0 0
}

.btn-sm,
.btn-group-sm>.btn {
    padding: .25rem .5rem;
    font-size: .765625rem;
    line-height: 1.5;
    border-radius: .2rem
}
    </style>
    <body>
    
    <div id="loading">
        <div id="loading-center">
        </div>
    </div>
    <div class="wrapper">
       <div class="container-fluid mt-100 mb-100">
          <div id="ui-view">
    <div>
    <div class="card">
        <div class="card-header"> Invoice<strong>#BBB-245432</strong>
            <!--<div class="pull-right"> <a class="btn btn-sm btn-info" href="#" data-abc="true"><i class="fa fa-print mr-1"></i> Print</a> <a class="btn btn-sm btn-info" href="#" data-abc="true"><i class="fa fa-file-text-o mr-1"></i> Save</a></div>-->
            </div>
            <div class="card-body">
                <div class="row mb-4">
                    <?php if(!empty($data)){
                             $member_detail = $data['member_detail'];
                             $plan_detail = $data['plan_detail'];
                        } ?>
                    <!--<div class="col-sm-4">-->
                    <!--    <h6 class="mb-3">From:</h6>-->
                    <!--    <div><strong>BBBootstrap Inc.</strong></div>-->
                    <!--    <div>546 Aston Avenue</div>-->
                    <!--    <div>NYC, NY 12394</div>-->
                    <!--    <div>Email: contact@bbbootstrap.com</div>-->
                    <!--    <div>Phone: +1 848 389 9289</div>-->
                    <!--</div>-->
                    <div class="col-sm-4">
                        <h6 class="mb-3">Details:</h6>
                        <div>Invoice<strong>N-195520</strong></div>
                        <div>Name: <?php echo isset($member_detail['name'])?$member_detail['name']:''; ?></div>
                        <div>Month: Feb-22</div>
                        <div>Chit-Discount Date/Auction Date: 6-Feb-22</div>
                    </div>
                    
                    <div class="col-sm-8">
                        <h6 class="mb-3"></h6>
                        <div>Cust#<strong>MYM0482</strong></div>
                        <div>Mob#: <?php echo isset($member_detail['mobile'])?$member_detail['mobile']:''; ?></div>
                    </div>
                </div>
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Plan Name</th>
                                <th>Tenure</th>
                                <th>EMI</th>
                                <th>Share of Discount</th>
                                <th>Mth</th>
                                <th>Rem</th>
                                <th>Discount Amt </th>
                                <th>End_Mth</th>
                                <th>Total Share of Discount</th>
                                <th>Chit Tkn?</th>
                            </tr>
                        </thead>
                        <?php if(!empty($plan_detail)){
                            $sum_of_emi = 0; $sum_of_divident = 0;
                            foreach($plan_detail as $keys=>$values){
                                    $sum_of_emi += isset($values['emi']) ? $values['emi'] :'0';
                                    $sum_of_divident += isset($values['total_divident_amount']) ? $values['total_divident_amount'] :'0';
                                ?>
                        <tbody>
                            <tr>
                                <td class="left"><?php echo isset($values['plan_name']) ? $values['plan_name'] :'' ?></td>
                                <td class="left"><?php echo isset($values['tenure']) ? $values['tenure'] :'' ?></td>
                                <td class="center">₹<?php echo isset($values['emi']) ? $values['emi'] :'' ?></td>
                                <td class="right">₹<?php echo isset($values['total_divident_amount']) ? $values['total_divident_amount'] :'0' ?></td>
                                <td class="right"><?php echo isset($values['total_months']) ? $values['total_months'] :'' ?></td>
                                <td class="left"><?php echo isset($values['remaining_month']) ? $values['remaining_month'] :'' ?></td>
                                <td class="center"><?php echo isset($values['bid_amount']) ? $values['bid_amount'] :'0' ?></td>
                                <td class="right"><?php echo isset($values['end_date_for_subscription']) ? $values['end_date_for_subscription'] :'' ?></td>
                                <td class="right"><?php echo isset($values['total_divident_amount']) ? $values['total_divident_amount'] :'0' ?></td>
                                <td class="right"><?php echo isset($values['chit_amount']) ? $values['chit_amount'] :'No' ?></td>
                            </tr>
                        </tbody>
                        <?php
                            }}
                         ?>
                    </table>
                </div>
                <div class="row">
                    <div class="col-lg-5">
                        <table class="table table-clear">
                            <tbody>
                                <tr style="background: darkgray;">
                                    <td class="left"><strong>Total</strong></td>
                                    <td style="width:7%;"></td>
                                    <td class="right" style="text-align: center;">₹<?php echo isset($sum_of_emi) ? $sum_of_emi :'0' ?></td>
                                    <td class="right">₹<?php echo isset($sum_of_divident) ? $sum_of_divident :'0' ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-lg-6">
                        <table class="table table-clear">
                            <!--<tbody>-->
                                <tr style="background: beige;">
                                    <td class="left"><strong>Net Payment Calculation</strong></td>
                                    <td class="right"></td>
                                    <!--<td></td>-->
                                </tr>
                                <tr>
                                    <td style="width:49%"><strong>Total EMI</strong></td>
                                    <td class="right">₹<?php echo isset($sum_of_emi) ? $sum_of_emi :'0' ?></td>
                                    <!--<td></td>-->
                                </tr>
                                <tr>
                                    <td class="left"><strong>Share of Discount</strong></td>
                                    <td class="right"><strong>₹-<?php echo isset($sum_of_divident) ? $sum_of_divident :'0' ?></strong></td>
                                    <!--<td></td>-->
                                </tr>
                                
                                <?php 
                                    $sum_of_emi = isset($sum_of_emi) ? $sum_of_emi :'0';
                                    $sum_of_divident = isset($sum_of_divident) ? $sum_of_divident :'0';
                                   $GrossAmount = ($sum_of_emi - $sum_of_divident);
                                ?>
                                
                                <tr style="background: coral;">
                                    <td class="left"><strong>Gross Amount</strong></td>
                                    <td class="right"><strong>₹<?php echo $GrossAmount; ?></strong></td>
                                    <!--<td></td>-->
                                </tr>
                            <!--</tbody>-->
                        </table>
                    </div>
                </div>
                
                <?php if(!empty($plan_detail)){
                    $chit_detail_for_invoice = array();
                            foreach($plan_detail as $keys=>$values){
                                if($values['chit_amount']!='No'){
                                    $chit_data = array(
                                        'plan_name'=>$values['plan_name'],
                                        'plan_amount'=>$values['plan_amount'],
                                        'winning_bid_amount'=>$values['winning_bid_amount']
                                        );
                                        $chit_detail_for_invoice[] = $chit_data;
                                }
                            }
                }
                ?>
                
                <?php if(!empty($chit_detail_for_invoice)){
                    $sum_of_plan_amount = 0;
                    $sum_of_winning_bid_amount = 0;
                    foreach($chit_detail_for_invoice as $k=>$v){
                        $sum_of_plan_amount+= isset($v['plan_amount'])?$v['plan_amount']:'0';
                        $sum_of_winning_bid_amount+= isset($v['winning_bid_amount'])?$v['winning_bid_amount']:'0';
                    ?> 
                <div class="row">
                    <div class="col-lg-6">
                        <table class="table table-clear">
                            <tbody>
                                <tr style="background: beige;">
                                    <td class="left"><strong>Chit Taken (if any)</strong></td>
                                    <td class="right"></td>
                                </tr>
                                <tr>
                                    <td class="left"><strong><?php echo isset($v['plan_name'])?$v['plan_name']:'' ?></strong></td>
                                    <td class="right" style="text-align: center;">₹<?php echo isset($v['plan_amount'])?$v['plan_amount']:'' ?></td>
                                </tr>
                                <tr>
                                    <td class="left"><strong>Less:Discount Amount</strong></td>
                                    <td class="right" style="text-align: center;"><strong>₹-<?php echo isset($v['winning_bid_amount'])?$v['winning_bid_amount']:'' ?></strong></td>
                                </tr>
                                <tr style="background: coral;">
                                    <td class="left"><strong>Principal Less Discount</strong></td>
                                    <td class="right" style="text-align: center;"><strong>₹<?php $defference_of_plan_amount_and_bid = $sum_of_plan_amount - $sum_of_winning_bid_amount; echo isset($defference_of_plan_amount_and_bid)?$defference_of_plan_amount_and_bid:''; ?></strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <?php
                }} ?>
                <div class="row">
                    <div class="col-lg-6">
                        <table class="table table-clear">
                            <tbody>
                                <tr style="background: lightblue;">
                                    <td class="left"><strong>NET AMOUNT PAYABLE</strong></td>
                                    <?php $g_amount = isset($GrossAmount)?$GrossAmount:'0';
                                        $pld = isset($defference_of_plan_amount_and_bid)?$defference_of_plan_amount_and_bid:'0';
                                        $defference_of_ga_pld = $g_amount - $pld; ?>
                                    <td class="right" style="text-align: center;">₹<?php echo isset($defference_of_ga_pld)?$defference_of_ga_pld:''  ;?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <h1> </h1>
            </div>
        </div>
    </div>
  </div>
       </div>
    </div>
</div>
        <?php include APPPATH . 'views/include/js.php'; ?>
    </body>
</html>