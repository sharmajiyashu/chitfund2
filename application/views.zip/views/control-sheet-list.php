<!doctype html>
<html lang="en">
    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
    <body class="  ">
        <!-- loader Start -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>
        <!-- loader END -->
        <!-- Wrapper Start -->
        <div class="wrapper">

            <?php include APPPATH . 'views/include/sidebar.php'; ?>  
            <?php include APPPATH . 'views/include/header.php'; ?>
            <div class="content-page">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                                <div>
                                    <h4 class="mb-3">Reports List</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="table-responsive rounded mb-3">
                                <table class="data-table table mb-0 tbl-server-info">
                                    <thead class="bg-white text-uppercase">
                                        <tr class="ligth ligth-data">
                                            <th>Sr No.</th>
                                            <th>Subscriber Name</th>
                                            <th>Mobile</th>
                                            <th>Opening Balance</th>
                                            <th>Current month due</th>
                                            <th>Chit Taken</th>
                                            <th>Other dues and payables</th>
                                            <th>Net Amount</th>
                                            <th>Paid Amount</th>
                                            <th>Balance Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="ligth-body">
                                        <?php if(isset($getControl) && is_array($getControl)) { ?>
                                        <?php $i=1; foreach($getControl as $key => $value){ ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo isset($value['Member_name']) ? $value['Member_name'] : ''; ?></td>
                                            <td><?php echo isset($value['Member_mobile']) ? $value['Member_mobile'] : ''; ?></td>
                                            <td><?php echo isset($value['Opening_balance']) ? $value['Opening_balance'] : '0'; ?></td>
                                            <td><?php echo isset($value['Current_month_due']) ? $value['Current_month_due'] : '0'; ?></td>
                                            <td><?php echo isset($value['Chit_taken']) ? $value['Chit_taken'] : '0'; ?></td>
                                            <td><?php //echo isset($value['Total_emi_due']) ? $value['Total_emi_due'] : ''; ?>0</td>
                                            <td><?php echo isset($value['Net_Amount']) ? $value['Net_Amount'] : '0'; ?></td>
                                            <td><?php echo isset($value['Total_emi_paid ']) ? $value['Total_emi_paid'] : '0'; ?></td>
                                            <td><?php echo isset($value['Balance_amount']) ? $value['Balance_amount'] : '0'; ?></td>
                                        </tr>
                                        <?php $i++; } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <!-- Page end  -->
                </div>
            </div>
        </div>
        <!-- Wrapper End-->
        <?php // footer?>
        <?php include APPPATH . 'views/include/js.php'; ?>
        <script>
            $(".data-delete").click(function () {
                if (!confirm("Do you really want to delete this?")) {
                    return false;
                }
            });

        </script>
    </body>
</html>