<!doctype html>
<html lang="en">
    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
    <body class="  ">
    <?php include APPPATH . 'views/include/sidebar.php'; ?>  
            <?php include APPPATH . 'views/include/header.php'; ?>
        <!-- loader Start -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>
        <!-- loader END -->
        <!-- Wrapper Start -->
        <div class="wrapper">
           
            <div class="content-page">
                <div class="container-fluid">
                  <form action="<?php echo base_url(); ?>Dashboard/chidHandover" method="POST">

                  <div class="col-lg-12">
                      <h5 style="color: black;">Chit Detail</h5>
                      <div class="col-lg-10" style="border-radius: 10px;background: aliceblue;border: 1px solid darkgray;padding: 16px;" >
                          <div><h6 style="color: darkslategray;">Plan Name <span style="margin-left: 99px"> : <?php echo isset($plan_detail['plan_name']) ? $plan_detail['plan_name'] : 'Null'; ?></span></h6></div>
                          <div><h6 style="color: darkslategray;">Group Name <span style="margin-left: 86px;"> : <?php echo isset($plan_detail['group_name']) ? $plan_detail['group_name'] : 'X'; ?></span></h6></div>
                          <div><h6 style="color: darkslategray;">Return Chit Amount <span style="margin-left: 32px;"> : <?php echo isset($plan_detail['return_chit_amount']) ? $plan_detail['return_chit_amount'] : '00'; ?></span></h6></div>
                          <div><h6 style="color: darkslategray;">Forgo Amount <span style="margin-left: 74px;"> : <?php echo isset($plan_detail['forgo_amount']) ? $plan_detail['forgo_amount'] : '00'; ?></span></h6></div>
                          <div><h6 style="color: darkslategray;">Amount To Pay <span style="margin-left: 70px;color :red;"> : <?php echo isset($data['chit_emi_total_due_amount']) ? $data['chit_emi_total_due_amount'] : '00'; ?></span> </h6></div>
                      </div>
                  </div>
                  <div class="col-lg-12">
                      <h5 style="color: black;">Subscriber Dues</h5>
                      <div class="col-lg-10" style="border-radius: 10px;background: aliceblue;border: 1px solid darkgray;padding: 16px;" >
                          <div><h6 style="color: darkslategray;">Emi <span style="margin-left: 119px;color: cadetblue;"> : <?php echo isset($data['emi_total_due_amount']) ? $data['emi_total_due_amount'] : ''; ?> </span></h6></div>
                          <div><h6 style="color: darkslategray;">Additional Due <span style="margin-left: 38px;color: cadetblue;"> : <?php echo isset($data['additional_dues']) ? $data['additional_dues'] : ''; ?> </span></h6></div>
                          <div><h6 style="color: darkslategray;">registration <span style="margin-left: 62px;color: cadetblue;"> : <?php echo isset($data['registration_dues']) ? $data['registration_dues'] : ''; ?> </span></h6></div>                         
                      </div>
                  </div>
                  <div class="col-lg-12">
                  <h5></h5>
                  <?php $total_chit = isset($plan_detail['return_chit_amount']) ? $plan_detail['return_chit_amount'] : '0';
                        $total_emi_due = isset($data['emi_total_due_amount']) ? $data['emi_total_due_amount'] : '0';
                        $total_final_payment = $total_chit - $total_emi_due;
                  ?>

                      <div class="col-lg-10" style="border-radius: 10px;background: aliceblue;border: 1px solid darkgray;padding: 16px;margin-top: 18px;" >
                          <div><h6 style="color: darkslategray;text-align: center;padding-bottom: 10px;">Final Payment = Amount To Payment - Subscriber Total Dues</h6></div>
                          <div style="border-top: 2px solid darkgray; text-align: center;font-size: 31px;"><h6 style="color: darkslategray;">Final Amount : <span style="color:red"> <?php echo isset($total_final_payment) ? $total_final_payment :'0' ?> </span>  </h6></div>
                      </div>                      
                  </div>
 <?php if(!empty($plan_detail['plan_name'])){ ?>
                    <div class="col-lg-12"  >                        
                            <div  class="col-lg-10" style="background: oldlace;border: 1px solid darkgray;height: auto;padding:20px;border-radius: 10px;margin-top: 20px;margin-bottom:20px;">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h5>Amount To Pay:</h5>
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="amount" style="width:100%;background: darkgray;" readonly id="amount_pay" value="<?php echo isset($total_final_payment) ?  $total_final_payment : '';?>">
                                        <input type="hidden" name="chit_id" value="<?php echo isset($plan_detail['chit_id']) ? $plan_detail['chit_id'] :'' ?>">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label>Payment Method</label>       
                                                <select class="form-control" id="payment_mode" name="payment_mode">
                                                    <option value="">Select Payment Type</option>
                                                    <option value="online">Online</option>
                                                    <option value="cheque">Cheque</option>
                                                    <option value="offline">Cash</option>
                                                </select>
                                        </div> 
                                    </div>

                                        <div class="col-md-4" id="bank_account">
                                            <div class="form-group">
                                                <label>Bank Account</label>       
                                                <select class="form-control" name="bank_account_id">
                                                    <option value="">Select Bank Type</option>
                                                    <option value="1">Sbi</option>
                                                    <option value="1">PNB</option>
                                                    <option value="1">Axis</option>
                                                </select>
                                            </div> 
                                        </div>
                                            
                                        <div class="col-md-4" id="cheque_number" >
                                            <label>Cheque Number</label><br>
                                            <input type="text"  placeholder="Enter Cheque Number" style="width:100%;" name="cheque_no">
                                        </div>
                                    </div>

<div class="row">
                                    <!-- <div> -->
                                      <button class="btn btn-success" style="margin-left:50%">Submit</button>
                                    <!-- </div> -->
</div>
                                    <!-- <div>
                                    </div> -->
                                </div>                                
                            </div> 
                        </div>
                  </form>
                    </div>
                </div> 
<?php }?>  
        </div>
        <!-- Wrapper End-->
        <?php // footer?>
        <?php include APPPATH . 'views/include/js.php'; ?>
        
        <script>
            $(document).ready(function(){
               $("#cheque_number").hide(); 
            });
        </script>
    
        <script>
         $("#payment_mode").on('change',function(){
            var payment_value = $(this).val();
            if(payment_value == "cheque"){
              $("#cheque_number").show();  
            }
            if(payment_value == "offline"){
               $("#cheque_number").hide(); 
               $("#bank_account").hide(); 
            }
         });
        </script>
        
        <script>
         $(".Payemi").on('change',function(){
           let doc_arr = [];
           let id = $(this).attr('emi_id');     
           let amount = $("#number_"+id).val();
           $("#abc_"+id).val(amount);
           //Multiple choose checkbox then get the value input box
           let selectedValues = $('input[name="checkbox"]:checked').map(function() {return this.value;}).get(); 
           const numbers = selectedValues.map(Number);
           const sum = numbers.reduce((partialSum, a) => partialSum + a, 0);
           $("#amount_pay").val(sum);
            
          
          $('input[name="checkbox"]:checked').each(function(){
            let emi_id = $(this).attr('emi_id');
           doc_arr.push({"id":emi_id,"amount":this.value,"status":'plan_emi'});
          });
          
          let json_doc_data = JSON.stringify(doc_arr);
          $("#doc").val(json_doc_data);
         
         });   
        </script>
        
        <!--<script>-->
        <!-- $(".amount").on('click',function(){-->
        <!--     let id = $(this).val();    -->
        <!--    $("#abc_"+id).prop('checked', false);-->
        <!-- });-->
        <!--</script>-->
    </body>
</html>