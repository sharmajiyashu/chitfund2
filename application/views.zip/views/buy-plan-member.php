<!doctype html>
<html lang="en">
    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
    <body class="  ">
        <!-- loader Start -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>
        <!-- loader END -->
        <!-- Wrapper Start -->
        <div class="wrapper">
            <?php include APPPATH . 'views/include/sidebar.php'; ?>  
            <?php include APPPATH . 'views/include/header.php'; ?>
            <div class="content-page">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                                <div>
                                    <h4 class="mb-3">Available Plan</h4>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                             <?php if ($this->session->flashdata('success')) { ?>
                            <div class="alert alert-success" style="clear:both;color: #44a942 !important; background-color: green !important; border-color: #ebccd1 !important;">
                                <span  class="closebtn"  onclick="this.parentElement.style.display = 'none';">&times;</span> 
                                <strong>
                                    <?php echo $this->session->flashdata('success'); ?></strong></div>  <?php } ?>
                
                                    <?php if ($this->session->flashdata('Failure')) { ?>
                            <div class="alert alert-warning" style="clear:both;color: azure; background-color: green; border-color: #ebccd1 !important;">
                                <span  class="closebtn"  onclick="this.parentElement.style.display = 'none';">&times;</span> 
                            <strong>
                            <?php echo $this->session->flashdata('Failure'); ?></strong></div>  <?php } ?>
                                                           
                            <div class="row">
                                        <?php if (isset($data) && is_array($data)) { ?>
                                            <?php $i=1; foreach($data as $key => $values) {  
                                                ?> 
                                         
                                             <div class="col-lg-4" style=""  >
                                                <div class="card shadow-sm" >      
                                                    <div style="padding: 16px;">             
                                                        <h6> Plan Name  <span style="color:red;margin-left: 82px">: <?php echo isset($values['plan_name']) ? $values['plan_name'] :'' ?></span></h6>                              
                                                        <h6> Plan Amount <span style="color:red;margin-left: 66px"> : <?php echo isset($values['plan_amount']) ? $values['plan_amount'] :'' ?></span></h6> 
                                                        <div class="row" style="margin-top: 15px;">
                                                            <div class="col-lg-7">
                                                                 <div class="form-group">
                                                                    <form id="myform" action="<?php echo base_url(); ?>Dashboard/buy_plan_by_agent/" method="post"  class="dropzone" enctype="multipart/form-data">
                                                                    <select class="form-control" name="payment_mode"> 
                                                                    <option value="offline" name="payment_mode" >Offline Payment</option>
                                                                    <option value="online" name="payment_mode">Online Payment</option>
                                                                    <input type="hidden" name="plan_id" value="<?php echo isset($values['plan_id']) ? $values['plan_id'] : '' ;  ?>"/>  
                                                                    <input type="hidden" name="member_id" value="<?php echo isset($member_id) ? $member_id : '' ;  ?>"/> 
                                                                    </select>
                                                                </div> 
                                                            </div>
                                                            <div class="col-lg-4">
                                                                <div> <button class="btn btn-dark" style="margin-left: ;margin-top: 2px;" name="submit">  <span style="font-size: 10px;"> BUY PLAN </span></button> </div>    
                                                            </div>
                                                            </form>
                                                        </div>
                                                       
                                                        
                                                    </div>                                
                                                </div> 
                                             </div>                                                 
                                            
                                            <?php $i++; } ?>
                                        <?php } ?>
                                        </div> 
                                        
                            </div>
                        </div>
                    </div>
                    <!-- Page end  -->
                </div>
            </div>
        </div>
        <!-- Wrapper End-->
        <?php // footer?>
        <?php include APPPATH . 'views/include/js.php'; ?>
        <script>
            $(".data-delete").click(function () {
                if (!confirm("Do you really want to delete this?")) {
                    return false;
                }
            });

        </script>
    </body>
</html>