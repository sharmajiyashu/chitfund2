    <!doctype html>
<html lang="en">
    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
    <body class="  ">
        <!-- loader Start -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>
        <!-- loader END -->
        <!-- Wrapper Start -->
        <div class="wrapper">
            <?php include APPPATH . 'views/include/sidebar.php'; ?>  
			<?php include APPPATH . 'views/include/header.php'; ?>
            <div class="content-page">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                                <div>
                                    <h4 class="mb-3">Auction summary</h4>
                                </div>
                                
                                <?php if ($this->session->flashdata('success')) { ?>
                            <div class="alert alert-success" style="clear:both;color: #44a942 !important; background-color: #a1e9b4 !important; border-color: #ebccd1 !important;">
                                <span  class="closebtn"  onclick="this.parentElement.style.display = 'none';">&times;</span> 
                                <strong>
                                    <?php echo $this->session->flashdata('success'); ?></strong></div>  <?php } ?>
                
                                    <?php if ($this->session->flashdata('Failure')) { ?>
                            <div class="alert alert-success" style="clear:both;color: azure; background-color: brown; border-color: #ebccd1 !important;">
                                <span  class="closebtn"  onclick="this.parentElement.style.display = 'none';">&times;</span> 
                            <strong>
                            <?php echo $this->session->flashdata('Failure'); ?></strong></div>  <?php } ?>
                                
                                
                                
                                    <div class="col-lg-12">
                                    <?php 
                                        if(!empty($data['bid_data'])){
                                            foreach ($data['bid_data'] as $key=>$value){
                                                if($value['is_bid_accepted'] == 'yes'){
                                                    $sub_winning_id = isset($value['member_id']) ? $value['member_id'] :''  ;
                                                    $winnin_bid_amount = isset($value['forgo_amount']) ? $value['forgo_amount'] :''  ;                                         
                                                }                                      
                                            }
                                        }
                                    ?>           
                                         <div class="card shadow-sm" >  
                                                <div class="col-lg-12">
                                                    <div class="row" >                                                  
                                                    <div style="padding: 16px;" class="col-lg-6">    
                                                        <div> <h5>Plan Name <span style="margin-left: 123px;">:  <?php echo isset($data['plan_name']) ? $data['plan_name'] : '' ; ?></span></h5></div>   
                                                        <div> <h5>Auction Group <span style="margin-left: 91px;">:  <?php  echo isset($data['group_name']) ? $data['group_name'] :'' ; ?></span></h5> </div>   
                                                        <div> <h5>Winning Subscrider ID <span style="margin-left: 25px;">:  <?php echo isset($sub_winning_id) ? $sub_winning_id : '0000000';?></span> </h5></div> 
                                                     </div>
                                                     <div style="padding: px;" class="col-lg-6">
                                                        <div class="card shadow-sm" style="width: 49%;padding: 10px;margin-top: 17px;margin-left: 118px;margin-bottom: -13px;">    
                                                            <div> <h5 style="color: chocolate;margin-left: 84px;"> ₹ <?php echo isset($winnin_bid_amount) ?$winnin_bid_amount : '00000' ; ?></h5></div>   
                                                            <div> <span style="margin-left: 14px;">Winning Discount  Amount </span> </div>                                                              
                                                        </div> 
                                                     </div>  
                                                 </div> 
                                              </div> 
                                          </div>
                                       </div> 
                                 </div>
                            </div>
                        </div>
                        
    
                        <div class="col-lg-12">   
                         <?php if (isset($data['bid_data']) && is_array($data) && !empty($data['bid_data'])) { ?>
                         <?php $i=1; foreach($data['bid_data'] as $key => $values) {   ?>  
                        <div class="row">
                          <div class="col-lg-4">
                          <div class="card shadow-sm">
                             <div style="padding: 10px;">
                               <?php if($values['is_bid_accepted'] == 'yes'){ ?>
                                 <div><h6 style="color: crimson;">Sub.id <?php echo isset($values['member_id']) ? $values['member_id'] :'' ?> has placed a discount  - ₹ <?php echo isset($values['forgo_amount']) ? $values['forgo_amount'] :''  ?> </h6></div>
                               <?php } else{ ?>
                                 <div><h6>Sub.id <?php echo isset($values['member_id']) ? $values['member_id'] :'' ?> has placed a discount  - ₹ <?php echo isset($values['forgo_amount']) ? $values['forgo_amount'] :''  ?> </h6></div>
                               <?php } ?>   
                              </div>
                          </div>
                          </div>
                        </div>
                        <?php $i++; } ?>
                        <?php }else{ ?>
                             <h3>Discount List Not Available for this auction</h3>
                        <?php } ?>
                        </div>
                       
                        </div>
                    </div>
                    <!-- Page end  -->
                </div>
            </div>
        </div>
    
        <!-- Wrapper End-->
        <?php // footer?>
        <?php include APPPATH . 'views/include/js.php'; ?>
        <script>
            $(".data-delete").click(function () {
                if (!confirm("Do you really want to delete this?")) {
                    return false;
                }
            });
        </script>
    </body>
</html>