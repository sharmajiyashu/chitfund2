
<!doctype html>
<html lang="en">

    <head>
        <?php include APPPATH . 'views/include/css.php'; ?>
    </head>
     <style>
      .error{
          color:#E08DB4;
      }

    </style>
    <body class="  ">
        <!-- loader Start -->
        <div id="loading">
            <div id="loading-center">
            </div>
        </div>
        <!-- loader END -->
        <!-- Wrapper Start -->
        <div class="wrapper">

            <?php include APPPATH . 'views/include/sidebar.php'; ?>  
            <?php include APPPATH . 'views/include/header.php'; ?>
            <div class="content-page">
                <div class="container-fluid add-form-list">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between">
                                    <div class="header-title">
                                        <?php if(!empty($data['plan_id'])){ ?> 
                                        <h4 class="card-title">
                                          Update Subscription 
                                          <?php } else{ ?>
                                          Add Subscription 
                                        </h4>
                                       <?php } ?> 
                                    </div>
                                </div>
                                
                                <div class="card-body">
                                    <form id="myform" action="<?php echo base_url(); ?>Dashboard/addSubscription" method="post" data-toggle="validator">
                                     
                                        <input type="hidden" name="plan_id" value="<?php echo isset($data['plan_id']) ? $data['plan_id'] : '' ;  ?>" />  
                                                                       
                                         <div class="row"> 
                                            <div class="col-md-6">                      
                                                <div class="form-group">
                                                    <label>Plan Name *</label>
                                                    <input type="text" class="form-control" placeholder="Enter plan" required  name="plan_name" name="plan_name" value="<?php echo isset($data['plan_name']) ? $data['plan_name'] : ''; ?>">
                                                    <div><font color='red'><?php echo form_error('fname'); ?></font></div>
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>    
                                            <div class="col-md-6">                      
                                                <div class="form-group">
                                                    <label> Admission Fee *</label>
                                                    <input type="text" class="form-control" placeholder="Enter Admission Fee in percentage %"  required name="admission_fee"  name="admission_fee"  value="<?php echo isset($data['admission_fee']) ? $data['admission_fee'] : ''; ?>">
                                                    <div><font color='red'><?php echo form_error('lname'); ?></font></div>
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>    
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Plan Amount *</label>
                                                    <input type="text" class="form-control" placeholder="Enter Plan Amount"  name="plan_amount"  required name="plan_amount" value="<?php echo isset($data['plan_amount']) ? $data['plan_amount'] : ''; ?>">
                                                    <div><font color='red'><?php echo form_error('email'); ?></font></div>
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Tenure *</label>
                                                    <input type="number" class="form-control" placeholder="Enter Tenure"  required name="tenure" name="tenure" value="<?php echo isset($data['tenure']) ? $data['tenure'] : ''; ?>">
                                                    <div><font color='red'><?php echo form_error('phone_no'); ?></font></div>
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div> 
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Start Month *</label>
                                                    <input type="date" class="form-control" id="start_month" placeholder="Enter Start Month"  required name="start_month" name="start_month" value="<?php echo isset($data['start_month']) ? $data['start_month'] : ''; ?>">
                                                    <div><font color='red'><?php echo form_error('gst_no'); ?></font></div>
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Agent Commission *</label>
                                                    <input type="number" id="txtNumber" class="form-control" placeholder="Enter Agent commission in percentage % "  required name="agent_commission" name="agent_commission"   value="<?php echo isset($data['agent_commission']) ? $data['agent_commission'] : ''; ?>">
                                                    <!--<div class="help-block with-errors"></div>-->
                                                    
                                                </div>
                                            </div>
                                        
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Total Months *</label>
                                                    <input type="text" class="form-control" id="total_month" placeholder="Enter Total Month" required name="total_months" value="<?php echo isset($data['total_months']) ? $data['total_months'] : ''; ?>">
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Group Counts *</label> 
                                                    <input type="text" class="form-control" placeholder="Enter Group Count" required name="groups_counts" value="<?php echo isset($data['groups_counts']) ? $data['groups_counts'] : ''; ?>">
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>End Date For Subscription *</label> 
                                                    <input type="text" readonly class="form-control" id="endSubscription" placeholder="Enter End Date For Subscription" required name="end_date_for_subscription" value="<?php echo isset($data['end_date_for_subscription']) ? $data['end_date_for_subscription'] : ''; ?>">
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>  
                                            <!--<div class="col-md-6">-->
                                            <!--    <div class="form-group">-->
                                            <!--        <label>Min prize Amount*</label>-->
                                            <!--        <input type="text" class="form-control" placeholder="Enter min prize amount" required  name="min_prize_amount" value="<?php echo isset($data['min_prize_amount']) ? $data['min_prize_amount'] : ''; ?>" >-->
                                                    <!--<div class="help-block with-errors"></div>-->
                                            <!--    </div>-->
                                            <!--</div> -->
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Foreman Fees*</label>
                                                    <input type="number" class="form-control" placeholder="Enter foreman fees in percentage % " required  name="foreman_fees" value="<?php echo isset($data['forman_fees']) ? $data['forman_fees'] : ''; ?>" >
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>
                                             <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Max Bid Amount *</label>
                                                    <input type="number" class="form-control" placeholder="Enter Max Bid in percentage % " required  name="max_bid" value="<?php echo isset($data['max_bid']) ? $data['max_bid'] : ''; ?>" >
                                                    <!--<div class="help-block with-errors"></div>-->
                                                </div>
                                            </div>
                                        </div>     
                                        <?php if(!empty($data['plan_id'])){ ?> 
                                            <button type="submit" class="btn btn-primary mr-2" name="submit" value="submit"> Update Subscription </button> 
                                        <?php } else{ ?>  
                                           <button type="submit" class="btn btn-primary mr-2" name="submit" value="submit">  Add Subscription </button>
                                        <?php } ?>
                                        <button type="reset" class="btn btn-danger">Reset</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Page end  -->
                </div>
            </div>
        </div>
        <!-- Wrapper End-->
        <?php // footer?>
        <?php include APPPATH . 'views/include/js.php'; ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
        <script>
             $(document).ready(function () {

                $("#myform").validate({

                    rules: {

                        agent_commission: {
                            required: true,
                            min: 1,
                            max:100
                        },   
                        foreman_fees: {
                            required: true,
                            min: 1,
                            max:100
                        },  
                         max_bid: {
                            required: true,
                            min: 1,
                            max:100
                        },  
                          
                          admission_fee: {
                            required: true,
                            min: 1,
                            max:100
                        },
                    },
                    messages: {

                        agent_commission: {
                            min: "Please enter valid Percentage ",
                            max: "Please enter valid Percentage"
                        },          
                         foreman_fees: {
                            min: "Please enter valid Percentage ",
                            max: "Please enter valid Percentage"
                        }, 
                        max_bid: {
                            min: "Please enter valid Percentage ",
                            max: "Please enter valid Percentage"
                        }, 
                         admission_fee: {
                            min: "Please enter valid Percentage ",
                            max: "Please enter valid Percentage"
                        }, 

                    }

                });
            });
        </script>
        
        <script>
        $('#num').keydown(function(e) {
          if (e.keyCode === 190 || e.keyCode === 110) {
            e.preventDefault();
          }
        });
        </script>
        
        <script>
            $("#total_month").on('change',function(){
                let start_month = $("#start_month").val();
                let total_month = $(this).val();
                let futureDate = convert(addMonths(new Date(start_month),total_month).toString());
                $("#endSubscription").val(futureDate);
            });
        </script>
        
        <script>
            function addMonths(date, months) {
                var d = date.getDate();
                date.setMonth(date.getMonth() + +months);
                if (date.getDate() != d) {
                  date.setDate(0);
                }
                return date;
            } 
            
            function convert(str) {
              var date = new Date(str),
                mnth = ("0" + (date.getMonth() + 1)).slice(-2),
                day = ("0" + date.getDate()).slice(-2);
              return [date.getFullYear(), mnth, day].join("-");
            }
        </script>
    </body>
</html>